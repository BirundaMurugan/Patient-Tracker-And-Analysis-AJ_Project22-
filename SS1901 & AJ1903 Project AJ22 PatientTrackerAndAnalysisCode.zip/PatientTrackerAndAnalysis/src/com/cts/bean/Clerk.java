package com.cts.bean;

public class Clerk {
	private int clerkId;
	private String first_Name;
	private String Last_Name;
	private int Age;
	private String Gender;
	private String DOB;
	private long Contact_No;
	private long Alt_Contact_No;
	private String Address_Line1;
	private String Address_line2;
	private String Email_id;
	private String City;
	private String State;
	private int ZipCode;
	public int getClerkId() {
		return clerkId;
	}
	public void setClerkId(int clerkId) {
		this.clerkId = clerkId;
	}
	public String getFirst_Name() {
		return first_Name;
	}
	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}
	public String getLast_Name() {
		return Last_Name;
	}
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public long getContact_No() {
		return Contact_No;
	}
	public void setContact_No(long contact_No) {
		Contact_No = contact_No;
	}
	public long getAlt_Contact_No() {
		return Alt_Contact_No;
	}
	public void setAlt_Contact_No(long alt_Contact_No) {
		Alt_Contact_No = alt_Contact_No;
	}
	public String getAddress_Line1() {
		return Address_Line1;
	}
	public void setAddress_Line1(String address_Line1) {
		Address_Line1 = address_Line1;
	}
	public String getAddress_line2() {
		return Address_line2;
	}
	public void setAddress_line2(String address_line2) {
		Address_line2 = address_line2;
	}
	public String getEmail_id() {
		return Email_id;
	}
	public void setEmail_id(String email_id) {
		Email_id = email_id;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public int getZipCode() {
		return ZipCode;
	}
	public void setZipCode(int zipCode) {
		ZipCode = zipCode;
	}
	

}
